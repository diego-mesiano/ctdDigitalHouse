package dev.diego.jenkinspringdocker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JenkinspringdockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JenkinspringdockerApplication.class, args);
	}

}
